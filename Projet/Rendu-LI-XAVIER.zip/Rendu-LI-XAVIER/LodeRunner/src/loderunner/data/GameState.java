package loderunner.data;

public enum GameState {
	Playing,
	Win,
	Loss
}
