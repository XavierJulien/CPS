package loderunner.services;

public interface GuardService extends CharacterService{

}
