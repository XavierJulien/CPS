package loderunner.data;

public enum ItemType {
	Treasure; //Tresor
}
