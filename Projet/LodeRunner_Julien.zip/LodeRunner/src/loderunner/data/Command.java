package loderunner.data;

public enum Command {
	UP,
	DOWN,
	LEFT,
	RIGHT,
	DIGL,
	DIGR,
	NEUTRAL
}
