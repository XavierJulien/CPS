package loderunner.data;

public enum ItemType {
	Treasure, //Tresor
	Gauntlet  //Gant de l'infinité
}
